package utils;

public class Constants {
	public static String InterfaceService = "interface_service";
	public static String EmailSend = "registration_successful";

	public static String AuthorizationService = "authorization_service";
	public static String LoginSend = "login_successful";

	public static String ClassifierService = "classifier_service";
	public static String SearchSend = "search_successful";

	public static String CompareService = "compare_service";
	public static String CompareSend = "compare_successful";
	
	public static String WelcomeService = "welcome_service";
	public static String WelcomeSend = "welcome_successful";
	
	
	

}